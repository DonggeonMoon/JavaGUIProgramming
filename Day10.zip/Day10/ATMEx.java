package Day10;

public class ATMEx {
	public static void main(String[] args) {
		ATM atm = new ATM("홍길동", 10000);
		ATMThread th = new ATMThread(atm);
		th.start();
		
	}
}

package Day10;
// synchronized: 쓰레드를 사용할 때 같은 데이터를 공유할 때 사용한다.
// balance를 공유하는데, 입출금이 동시에 일어나면 안 된다.
// synchronized 키워드를 사용하면, 하나의 처리가 끝나면 다음 처리가 데이터를
// 사용하게 처리하는 것이다. 
public class ATM {
	String account;
	int balance;
	
	ATM() {
		this.account = "A0001";
		this.balance = 10000;
	}
	
	ATM(String account, int balance) {
		this.account = account;
		this.balance = balance;
	}
	
	//deposit(): 입금하다.
	public synchronized void deposit(int money) {
		balance = balance + money;
		System.out.println(money + "원이 입금되었습니다.");
		System.out.println("잔액은 " + balance + "입니다.");
	}
	
	//withdraw(): 출금하다.
	public synchronized void withDraw(int money) {
		if (balance > money) {
			balance = balance - money;
			System.out.println(money + "원이 출금되었습니다.");
			System.out.println("잔액은 " + balance + "입니다.");
		} else {
			System.out.println("잔액이 모자랍니다.");
		}
	}
}

package Day10;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;

public class AwtEx3 extends Frame {
	Button btn1, btn2, btn3, btn4, btn5;
	
	public AwtEx3 () {
		super("Board Layout");
		setSize(400, 300); // frame size
		setLocation(600, 300);// frame location
		setVisible(true);// 보일지 말지
		
		BorderLayout bl = new BorderLayout();// 배치 관리자: 컨테이너에는 컴포넌트를 어떻게 배치할지 도와주는 배치관리자가 있다. Frame을 상속받으면 기본적으로 borderLayout 사용 가능
		setLayout(bl);
				
		btn1 = new Button("EAST");//매개변수의 값을 버튼 위에 나타냄
		btn2 = new Button("WEST");// 캡션 값이다.
		btn3 = new Button("SOUTH");
		btn4 = new Button("NORTH");
		btn5 = new Button("CENTER");
		
		add(btn1, bl.EAST);
		add(btn2, bl.WEST);
		add(btn3, bl.SOUTH);
		add(btn4, bl.NORTH);
		add(btn5, bl.CENTER);
		
	}
	public static void main(String[] args) {
		new AwtEx3();
	}

}

package Day10;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;

public class AwtEx4 extends Frame {
	Button btn1, btn2, btn3, btn4, btn5;
	
	public AwtEx4 () {
		super("Board Layout");
		setSize(400, 300); // frame size
		setLocation(600, 300);// frame location
		setVisible(true);// 보일지 말지
		
		FlowLayout bl = new FlowLayout();// 배치 관리자: 컨테이너에는 컴포넌트를 어떻게 배치할지 도와주는 배치관리자가 있다. Frame을 상속받으면 기본적으로 borderLayout 사용 가능
		setLayout(bl);
				
		btn1 = new Button("EAST");//매개변수의 값을 버튼 위에 나타냄
		btn2 = new Button("WEST");// 캡션 값이다.
		btn3 = new Button("SOUTH");
		btn4 = new Button("NORTH");
		btn5 = new Button("CENTER");
		
		add(btn1);
		add(btn2);
		add(btn3);
		add(btn4);
		add(btn5);
		
	}
	public static void main(String[] args) {
		new AwtEx4();
	}

}

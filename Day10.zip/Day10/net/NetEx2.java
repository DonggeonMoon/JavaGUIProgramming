package Day10.net;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class NetEx2 {

	public static void main(String[] args) {
		try {
			Socket s = new Socket("192.168.0.11", 5000);
			InputStream is = s.getInputStream();
			OutputStream os = s.getOutputStream();
			
			InputStreamReader isr1 = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr1);
			
			System.out.println("입력하세요 : ");
			InputStreamReader isr2 = new InputStreamReader(System.in);
			BufferedReader keyboard = new BufferedReader(isr2);
			OutputStreamWriter osw = new OutputStreamWriter(os);
			BufferedWriter bw = new BufferedWriter(osw);
			PrintWriter pw = new PrintWriter(bw);
			
			String msg = null;
			String message = null;
			
			while((msg = keyboard.readLine()) != null) {
				System.out.println("내가 입력한 내용 : " + msg);
				pw.println("클라이언트 메세지 : " + msg);
				pw.flush();
				
				message = br.readLine();
				System.out.println(message);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

}

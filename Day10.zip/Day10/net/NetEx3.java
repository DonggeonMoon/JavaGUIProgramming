package Day10.net;
//server class
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class NetEx3 {
	public static void main(String[] args) {
		try {
			ServerSocket ss = new ServerSocket(5000);
			System.out.println("접속을 기다리는 중......");
			Socket client = ss.accept();
			InetAddress inet = client.getInetAddress();
			
			System.out.println("현재 접속한 pc의 IP : " + inet.getHostAddress());
			InputStream is = client.getInputStream();
			OutputStream os = client.getOutputStream();
			
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			
			OutputStreamWriter osw = new OutputStreamWriter(os);
			BufferedWriter bw = new BufferedWriter(osw);
			
			PrintWriter pw = new PrintWriter(bw);
			String m = null;
			while((m=br.readLine()) != null) {
				System.out.println(inet.getHostAddress() + " : " + m);
				pw.println("서버가 리턴한 메세지" + m);
				pw.flush();
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

}

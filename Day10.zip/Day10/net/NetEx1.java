package Day10.net;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class NetEx1 {

	public static void main(String[] args) throws UnknownHostException{
	
		InetAddress inet = InetAddress.getLocalHost();
		
		System.out.println(inet);
		System.out.println(inet.getHostAddress());
		System.out.println(inet.getHostName());
		System.out.println("---------------");
		//네이버의 주소가 궁금하다.
		
		InetAddress naver = InetAddress.getByName("www.naver.com");
		System.out.println(naver.getHostName());
		System.out.println(naver.getHostAddress());
		
		InetAddress google = InetAddress.getByName("www.google.com");
		System.out.println(google.getHostName());
		System.out.println(google.getHostAddress());
	}

}

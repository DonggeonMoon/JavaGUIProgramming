package Day10.net;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import javax.swing.*;

public class ChatClient extends JFrame implements ActionListener, KeyListener, Runnable{
	JButton jbtn1, jbtn2, jbtn3;
	JPanel jp1, jp2, jp3;
	JTextField jtf1, jtf2;
	JTextArea jta;
	JLabel jl;
	JScrollPane jsp;
	CardLayout layout;
	
	Socket s;
	PrintWriter pw;
	BufferedReader br;
	
	String ip;
	
	public ChatClient() {
		super("채팅클라이언트 v1.0");
		setBounds(100,100,400,300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		layout = new CardLayout();
		setLayout(layout);
		
		jbtn1 = new JButton("Login");
		jbtn2 = new JButton("Exit");
		jbtn3 = new JButton("Insert");
		
		jbtn1.setBounds(60,200,60,50);
		jbtn2.setBounds(180,200,60,50);
		
		jl = new JLabel("IP : ");
		jl.setBounds(40,60,60,50);
		
		jtf1 = new JTextField("192.168.0.11");
		jtf1.setBounds(100,60,150,40);
		
		jtf2 = new JTextField(25);
		
		jta = new JTextArea();
		
		jsp = new JScrollPane(jta, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
		jp1 = new JPanel();
		jp2 = new JPanel();
		jp3 = new JPanel();
		
		jp1.setLayout(null);
		jp1.add(jbtn1);
		jp1.add(jbtn2);
		jp1.add(jtf1);
		jp1.add(jl);
		
		Color c1 = new Color(229,234,245);
		jp1.setBackground(c1);
		add(jp1, "Login View");
		
		Color c2 = new Color(241,232,92);
		jp2.setLayout(new BorderLayout());
		jp2.add(jsp, "Center");
		add(jp2, "Chat");
		
		jp3.setBackground(c2);
		jp3.add(jtf2);
		jp3.add(jbtn3);
		
		jp2.add(jp3, "South");
		
		jbtn1.addActionListener(this);
		jbtn2.addActionListener(this);
		
		jtf2.addKeyListener(this);
		setVisible(true);
	}
	public static void main(String[] args) {
		new ChatClient();
	}
	
	public void run() {
		try {
			s = new Socket("192.168.0.11",5000);
			pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())));
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			
			String msg = null;
			while(true) {
				msg = br.readLine();
				jta.append(msg + "\n");
				JScrollBar bar = jsp.getVerticalScrollBar();
				int position = bar.getMaximum();
				bar.setValue(position);
			}			
		}catch(UnknownHostException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	@Override
	public void keyPressed(KeyEvent e) {
		int v = e.getKeyCode();
		if(v==KeyEvent.VK_ENTER) {
			String msg = jtf2.getText();
			jta.append("["+ip+"]"+msg+"\n");
			pw.println(msg);
			pw.flush();
			jtf2.setText("");
		}		
	}
	@Override
	public void keyReleased(KeyEvent e) {}
	@Override
	public void keyTyped(KeyEvent e) {}
	@Override
	public void actionPerformed(ActionEvent e) {
		Object o = e.getSource();
		if(o==jbtn1) {
			ip = jtf1.getText();
			layout.show(getContentPane(), "Chat");
			Thread th = new Thread(this);
			th.start();			
		}else if(o==jbtn2) {
			int result = JOptionPane.showConfirmDialog
					(this, "종료합니까?","진짜?", JOptionPane.YES_NO_CANCEL_OPTION);
			if(result == JOptionPane.OK_OPTION) {
				System.out.println("종료합니다.");
				System.exit(0);
			}
		}
		
	}
}

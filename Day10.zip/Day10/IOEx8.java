package Day10;

import java.io.*;
import Day10.Member;

public class IOEx8 {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		/*Member m = new Member();
		m.setId("Hong");
		m.setName("홍길동");
		m.setEmail("hong@naver.com");
		m.setAddress("서울시 구로구");
		m.setPw("password");
		*/
		Member m = new Member("Hong", "홍길동", "hong@naver.com", "서울시 구로구", "password");
		
		File f = new File("C:/javawork/member.dat");
		FileOutputStream fos = new FileOutputStream(f); 
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(m);
		
		FileInputStream fis = new FileInputStream(f);
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		Object obj = ois.readObject();
		
		Member m2 = (Member)obj;
		
		System.out.println("id:" + m2. getId());
		System.out.println("name: " + m2.getName());
		System.out.println("address: " + m2.getAddress());
		System.out.println("Email: " + m2.getEmail());
		System.out.println("Password: " + m2.getPw());			
	}
}

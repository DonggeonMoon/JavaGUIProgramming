package Day10;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AwtEx7 extends Frame implements ActionListener{

	Button btn;
	
	public AwtEx7() {
		super("Action Test");
		setSize(400,300);
		setLocation(600,200);
		setVisible(true);
		
		btn = new Button("click");
		add(btn,"South");
		
		btn.addActionListener(this);
	}
	public static void main(String[] args) {
		new AwtEx7();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("안녕하십니까.");
		
		Object obj = e.getSource();
		if(obj == btn) {
			this.setBackground(Color.BLACK);
		}
	}
}

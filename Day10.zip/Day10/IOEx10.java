package Day10;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class IOEx10 {

	public static void main(String[] args) throws IOException, ClassNotFoundException{
		
		
		Member m = new Member("Hong","홍길동","서울시 구로구",
				"hong@naver.com","password");
		File f = new File("C:/javawork/member.dat");
		File f1 = new File("C:/javawork/membercopy.dat");

		FileReader fr = new FileReader(f);
		FileWriter fw = new FileWriter(f1);
		
		BufferedReader br = new BufferedReader(fr);
		BufferedWriter bw = new BufferedWriter(fw);
		
		FileOutputStream fos = new FileOutputStream(f);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(m);
		
		FileInputStream fis = new FileInputStream(f);
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		Object obj = ois.readObject();
		
		Member m2 = (Member)obj;
		
		System.out.println("id : " + m2.getId());
		System.out.println("name : " + m2.getName());
		System.out.println("address : " + m2.getAddress());
		System.out.println("email : " + m2.getEmail());
		System.out.println("pw : " + m2.getPw());
		
	}

}

package Day10;

public class MyclassEx {

	public static void main(String[] args) {
		MyClass mc = new MyClass();
		mc.start();
		
		MyClass mc2 = new MyClass();
		mc2.start();
	}
}

package Day10;

import java.io.*;
import java.util.Scanner;

public class Practice {
	public static void main(String[] args) throws IOException {
		
		File f1 = new File("C:/javawork/input.txt");
		FileInputStream fis = new FileInputStream(f1);
		BufferedInputStream bis = new BufferedInputStream(fis);
		
		File f2 = new File("C:/javawork/output.txt");
		FileWriter fos = new FileWriter(f2);
		BufferedWriter bos = new BufferedWriter(fos);
		
		int a = 0;
		while((a = bis.read()) != -1 ) {
			System.out.print((char) a);
			bos.write(a);
		}
		
		Scanner sc = new Scanner(System.in);
		char[] s = sc.next().toCharArray();
		for (int i = 0; i<s.length;i++) {
			int b = (int) s[i];
			bos.write(b);
		}
		
		sc.close();
		bos.flush();
		bos.close();
		bis.close();
	}
}

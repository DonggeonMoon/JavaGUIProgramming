package Day10;

import java.awt.Button;
import java.awt.Frame;
//container(Frame)

public class AwtEx2 extends Frame {
	Button btn;
	
	public AwtEx2(String title) {
		super(title);
		setSize(400, 200);
		setLocation(597,289);
		btn = new Button("Click~!");
		add(btn);
		setVisible(true);
	}
	public static void main(String[] args) {
		AwtEx2 ae = new AwtEx2("버튼이 있는 윈도우");
		
	}

}

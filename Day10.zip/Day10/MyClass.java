package Day10;
//Thread 처리는 프로그래머가 할 수 있는 게 아니고,
//JVM이 알아서 처리한다.
//JVM이 있어서 프로그래머가 편한 점: 메모리 관리를 직접할 필요가 없다.
public class MyClass extends Thread {
	@Override
	public void run() {
	 for(int i = 0; i < 10; i++) { 
		 System.out.println(Thread.currentThread().getId() + "값" + i);
	 }
	 
	 try {
		 Thread.sleep(100);//
	 } catch(InterruptedException e) {
		 e.printStackTrace();
	 }
	}

}

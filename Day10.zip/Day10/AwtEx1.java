package Day10;

import java.awt.Frame;

public class AwtEx1 extends Frame {
	//AWT: Abstract Window Toolkit
	//component: 윈도우 상의 모든 구성요소
	
	AwtEx1(String title){
		super(title);
		setSize(300, 300);
		setLocation(400, 200);
		setVisible(true);
		
	}
	public static void main(String[] args) {
		AwtEx1 ae = new AwtEx1("내가 처음 만든 윈도우");
	
	}

}

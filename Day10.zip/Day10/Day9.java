package Day10;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class Day9 {
	public static void main(String[] args) throws IOException {
		
		// 숫자 형변환 시 NumberFormatException 예외 처리
		String sNum = "3456";//문자형 숫자니까, 숫자로 변환 가능
		String nNum = "Hello";
		
		try {
			int a = Integer.parseInt(sNum);
			System.out.println("sNum은 " + sNum);
			int b = Integer.parseInt(nNum);
			System.out.println("nNum은 " + nNum);
			
		} catch (NumberFormatException e) {
			System.out.println("숫자가 아닙니다. 숫자를 입력하세요.");
		}
		
		// 0으로 나눌 때 ArithmeticException 예외 처리
		int x = 5;
		
		try {
			int a = 100 / (5 - x);
		} catch (ArithmeticException e) {
			System.out.println("0으로 나눠서 오류가 발생했습니다.");
			e.printStackTrace();
		}
		
		File f = new File("C:/javawork/input.txt");
		FileWriter fw = new FileWriter(f);
		BufferedWriter bw = new BufferedWriter(fw);
		
		InputStreamReader isr = new InputStreamReader(System.in);
		int v = 0;
		while((v = isr.read()) != -1) {
			bw.write(v);
			System.out.println((char) v);
			if (v == 13) {
				bw.flush();
				bw.close();
				System.exit(-1);	
			}
		}
		
		bw.flush();
		bw.close(); // 자원 반납
	}
}

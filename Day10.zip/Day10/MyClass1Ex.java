package Day10;

public class MyClass1Ex {
	public static void main(String[] args) {
		MyClass1 mc = new MyClass1();
		mc.run();
		
		MyClass1 mc2 = new MyClass1();
		mc2.run();
	}

}

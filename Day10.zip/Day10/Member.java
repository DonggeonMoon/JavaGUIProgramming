package Day10;

import java.io.Serializable;
// 객체 직렬화, 주고받는 내용이 객체일 때는 직렬화 처리를 해줘야 된다.

public class Member implements Serializable {
	private String id, name, address, email;
	transient String pw;
	public Member() {}
	public Member(String id, String name, String address, String email, String pw) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.email = email;
		this.pw = pw;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
}

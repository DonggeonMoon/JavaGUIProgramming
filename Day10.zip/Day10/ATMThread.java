package Day10;

import java.util.*;
//Math.random(): 0 ~ 1 사이의 임의의 수

public class ATMThread extends Thread {
	ATM atm;
	Random rnd = new Random();
	
	public ATMThread(ATM atm) {
		this.atm = atm;
	}
	
	public void run() {
		boolean flag = false;
		
		for(int i = 1; i <= 10; i++) {
			int money = rnd.nextInt(10000);// 1~ 10000까지의 임의의 수를 발생시킴
			if(!flag) {
				atm.deposit(money);
			} else {
				atm.withDraw(money);
			}
			flag = !flag;//flag를 반전시킨다.
		}
	}
}

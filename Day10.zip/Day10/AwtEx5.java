package Day10;

import java.awt.Button;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AwtEx5 extends Frame{
	
	Button BtnYes, BtnNo;
	
	public AwtEx5(String title) {
		super("Event");
		setSize(400, 300);
		setLocation(600, 300);
		setVisible(true);
		
		setLayout(null);// 기본 배치관리자를 사용하지 않겠다.
		
		BtnYes = new Button("Yes");
		BtnNo = new Button("No");
		
		BtnYes.setSize(80, 30);
		BtnYes.setLocation(30, 250);
		
		BtnNo.setSize(80, 30);
		BtnNo.setLocation(150, 250);
		
		add(BtnYes);
		add(BtnNo);
		
		Handler hd= new Handler();
		BtnYes.addActionListener(hd);
	}
	
	public static void main(String[] args) {
		new AwtEx5("Event");
	}
	
	class Handler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Why click me~");
			
		} 
	}

}

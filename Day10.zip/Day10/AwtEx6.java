package Day10;

import java.awt.Button;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AwtEx6 extends Frame{

	Button btn;
	
	public AwtEx6() {
		super("Action Test");
		setSize(400,300);
		setLocation(600,200);
		setVisible(true);
		
		btn = new Button("click");
		add(btn,"South");
		
		Handler1 hd = new Handler1();
		btn.addActionListener(hd);
	}
	public static void main(String[] args) {
		new AwtEx6();
	}
	
	class Handler1 implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("안녕하세요.");
			System.exit(0);//종료해라. 매개변수 0 정상종료를 의미.
							//0외의 값은 비정상을 의미
		}
		
	}

}

package Day10;

import java.io.*;
/*
 * awt swing, javafx 비주얼 툴 - 거의 없다. 
 * java 자체로 applicaiton 개발할 수 있다.
 * 자체 애플리케이션을 개발해서 사용.
 * spring, web
 */

public class IOEx7 {
	public static void main(String[] args) throws IOException {
	File f = new File("c:/javawork/q6.txt");
	FileOutputStream fos = new FileOutputStream(f);
	BufferedOutputStream bos = new BufferedOutputStream(fos);
	
	InputStreamReader isr = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(isr);
	 
	int v = 0;
	while((v = br.read()) !=-1) {
		if(v == 10) {
			System.out.println("");
		} else if (v==13) {
			System.out.println("");
		} else { 
			bos.write(v+3);
		}
	}
	
	bos.flush();
	bos.close();
	System.out.println("종료되었습니다.");
	}
}
